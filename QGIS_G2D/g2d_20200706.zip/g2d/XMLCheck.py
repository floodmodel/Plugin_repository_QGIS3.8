# -*- coding: utf-8 -*-
import sys
import os
import os.path
import xml.etree.ElementTree as ET
from .lib.Util import *

_DEMFileToChange_Count=0
_BoundaryConditionData_Count=0
_BoundaryConditionData_ELCount=0
_Counts=[]
_ProjectFile=""

class xmls:
    def Check_Gmp_xml(self,filepath):
        try:
            test = XML_get_set()

            global _ProjectFile
            _ProjectFile =filepath
            # xml 요소 값을 배열에 넣음
            self.Set_XML_element_Project()
            self.Set_XML_element_HydroPars()
            self.Set_XML_element_DEMFileToChange()
            self.Set_XML_element_BoundaryConditionData()

            # xml 파싱
            doc = ET.parse(_ProjectFile)
            root = doc.getroot()

            G2DProject = ET.Element("projectds")
            G2DProject.set("xmlns", "http://tempuri.org/projectds.xsd")
            ProjectSettings = ET.SubElement(G2DProject, "ProjectSettings")
            for i in range(0, len(self.XML_element_Project)):
                for element in root.findall('{http://tempuri.org/projectds.xsd}ProjectSettings'):
                    Datavalue = element.findtext("{http://tempuri.org/projectds.xsd}" + self.XML_element_Project[i])
                    if self.XML_element_Project[i] == "DEMFile" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    elif self.XML_element_Project[i] == "LandCoverFile" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    elif self.XML_element_Project[i] == "LandCoverVatFile" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    elif self.XML_element_Project[i] == "CalculationTimeInterval_sec" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "1"
                    elif self.XML_element_Project[i] == "IsFixedDT" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "IsParallel" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "true"
                    elif self.XML_element_Project[i] == "MaxDegreeOfParallelism" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "10"
                    elif self.XML_element_Project[i] == "UsingGPU" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "EffCellThresholdForGPU" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "45000"

                    elif self.XML_element_Project[i] == "MaxIterationAllCellsOnCPU" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "7"
                    elif self.XML_element_Project[i] == "MaxIterationACellOnCPU" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "5"
                    elif self.XML_element_Project[i] == "MaxIterationAllCellsOnGPU" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "7"
                    elif self.XML_element_Project[i] == "MaxIterationACellOnGPU" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "5"

                    elif self.XML_element_Project[i] == "SimulationDuration_hr" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "25"
                    elif self.XML_element_Project[i] == "PrintoutInterval_min" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "10"
                    elif self.XML_element_Project[i] == "StartDateTime" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "0"
                    elif self.XML_element_Project[i] == "RainfallDataType" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "TextFileMAP"
                    elif self.XML_element_Project[i] == "RainfallDataInterval_min" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "10"
                    elif self.XML_element_Project[i] == "RainfallFile" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    elif self.XML_element_Project[i] == "BCDataInterval_min" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "10"
                    elif self.XML_element_Project[i] == "FloodingCellDepthThresholds_cm" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    elif self.XML_element_Project[i] == "OutputDepth" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "true"
                    elif self.XML_element_Project[i] == "OutputHeight" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "OutputVelocityMax" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "OutputFDofMaxV" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "OutputDischargeMax" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "OutputBCData" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "OutputRFGrid" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "OutputSinkData" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "OutputSourceAll" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                    elif self.XML_element_Project[i] == "MakeASCFile" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "true"
                    elif self.XML_element_Project[i] == "MakeImgFile" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "true"
                    elif self.XML_element_Project[i] == "DepthImgRendererMaxV" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "5"
                    elif self.XML_element_Project[i] == "HeightImgRendererMaxV" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "200"
                    elif self.XML_element_Project[i] == "VelocityMaxImgRendererMaxV" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "10"
                    elif self.XML_element_Project[i] == "DischargeImgRendererMaxV" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "10000"
                    elif self.XML_element_Project[i] == "RFImgRendererMaxV" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "30"
                    elif self.XML_element_Project[i] == "WriteLog" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                ET.SubElement(ProjectSettings, self.XML_element_Project[i]).text = Datavalue
  

            HydroPars = ET.SubElement(G2DProject, "HydroPars")
            for i in range(0, len(self.XML_element_HydroPars)):
                for element in root.findall('{http://tempuri.org/projectds.xsd}HydroPars'):
                    Datavalue = element.findtext("{http://tempuri.org/projectds.xsd}" + self.XML_element_HydroPars[i])
                    if self.XML_element_HydroPars[i] == "RoughnessCoeff" and (Datavalue == "" or  Datavalue == None):
                        #Datavalue = "0.03"
                        #2019-10-10 박: 수정 
                        Datavalue = "0.045"
                    if self.XML_element_HydroPars[i] == "DomainOutBedSlope" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "0.001"

                    if self.XML_element_HydroPars[i] == "InitialConditionType" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "Depth"

                    if self.XML_element_HydroPars[i] == "InitialCondition" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "0"

                    if self.XML_element_HydroPars[i] == "FroudeNumberCriteria" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "1"
                    if self.XML_element_HydroPars[i] == "CourantNumber" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "0.7"
                    if self.XML_element_HydroPars[i] == "ApplyVNC" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = "false"
                ET.SubElement(HydroPars, self.XML_element_HydroPars[i]).text = Datavalue

            global _BoundaryConditionData_Count,_Counts
            _BoundaryConditionData_Count=0
            _Counts=[]
            for element in root.findall('{http://tempuri.org/projectds.xsd}BoundaryConditionData'):
                BoundaryConditionData = ET.SubElement(G2DProject, "BoundaryConditionData")
                count = 0
                for i in range(0, len(self.XML_element_BoundaryConditionData)):
                    Datavalue = element.findtext("{http://tempuri.org/projectds.xsd}" + self.XML_element_BoundaryConditionData[i])
                    if self.XML_element_BoundaryConditionData[i] == "CellXY" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    if self.XML_element_BoundaryConditionData[i] == "DataFile" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    if self.XML_element_BoundaryConditionData[i] == "DataType" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    
                    ET.SubElement(BoundaryConditionData, self.XML_element_BoundaryConditionData[i]).text = Datavalue
                _BoundaryConditionData_Count = _BoundaryConditionData_Count +1
                test.setBoundaryConditionData_Count(_BoundaryConditionData_Count)




            global _DEMFileToChange_Count
            _DEMFileToChange_Count=0
            for element in root.findall('{http://tempuri.org/projectds.xsd}DEMFileToChange'):
                DEMFileToChange = ET.SubElement(G2DProject, "DEMFileToChange")
                for i in range(0, len(self.XML_element_DEMFileToChange)):
                    Datavalue = element.findtext("{http://tempuri.org/projectds.xsd}" + self.XML_element_DEMFileToChange[i])
                    if self.XML_element_DEMFileToChange[i] == "DEMFile" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    if self.XML_element_DEMFileToChange[i] == "TimeMinute" and (Datavalue == "" or  Datavalue == None):
                        Datavalue = ""
                    ET.SubElement(DEMFileToChange, self.XML_element_DEMFileToChange[i]).text = Datavalue
                _DEMFileToChange_Count = _DEMFileToChange_Count +1 
                test.setDEMFileToChange_Count(_DEMFileToChange_Count)



            ET.ElementTree(G2DProject).write(_ProjectFile, encoding="utf-8", xml_declaration=True)
            with open(_ProjectFile, 'r') as f:
                content = f.read()
            f = open(_ProjectFile, 'w')
            f.write(content)
            f.close()
            return test
        except Exception as e:
            MsError(e)

    def Set_XML_element_Project(self):
        try:
            self.XML_element_Project = []
            self.XML_element_Project.append('DEMFile')
            self.XML_element_Project.append('LandCoverFile')
            self.XML_element_Project.append('LandCoverVatFile')
            self.XML_element_Project.append('CalculationTimeInterval_sec')
            self.XML_element_Project.append('IsFixedDT')
            self.XML_element_Project.append('IsParallel')
            self.XML_element_Project.append('MaxDegreeOfParallelism')
            self.XML_element_Project.append('UsingGPU')
            self.XML_element_Project.append('EffCellThresholdForGPU')

            self.XML_element_Project.append('MaxIterationAllCellsOnCPU')
            self.XML_element_Project.append('MaxIterationACellOnCPU')
            self.XML_element_Project.append('MaxIterationAllCellsOnGPU')
            self.XML_element_Project.append('MaxIterationACellOnGPU')

            self.XML_element_Project.append('SimulationDuration_hr')
            self.XML_element_Project.append('PrintoutInterval_min')
            self.XML_element_Project.append('StartDateTime')
            self.XML_element_Project.append('RainfallDataType')
            self.XML_element_Project.append('RainfallDataInterval_min')
            self.XML_element_Project.append('RainfallFile')
            self.XML_element_Project.append('BCDataInterval_min')

            #2018-10-30 박:xml 추가
            self.XML_element_Project.append('FloodingCellDepthThresholds_cm')
            self.XML_element_Project.append('OutputDepth')
            self.XML_element_Project.append('OutputHeight')
            self.XML_element_Project.append('OutputVelocityMax')
            self.XML_element_Project.append('OutputFDofMaxV')
            self.XML_element_Project.append('OutputDischargeMax')
            self.XML_element_Project.append('OutputBCData')
            self.XML_element_Project.append('OutputRFGrid')
            self.XML_element_Project.append('OutputSinkData')
            self.XML_element_Project.append('OutputSourceAll')
            self.XML_element_Project.append('DepthImgRendererMaxV')
            self.XML_element_Project.append('HeightImgRendererMaxV')
            self.XML_element_Project.append('VelocityMaxImgRendererMaxV')
            self.XML_element_Project.append('DischargeImgRendererMaxV')
            self.XML_element_Project.append('RFImgRendererMaxV')
            self.XML_element_Project.append('MakeASCFile')
            self.XML_element_Project.append('MakeImgFile')
            self.XML_element_Project.append('WriteLog')
        except Exception as e:
            MsError(e)

    def Set_XML_element_HydroPars(self):
        self.XML_element_HydroPars = []
        self.XML_element_HydroPars.append('RoughnessCoeff')
        self.XML_element_HydroPars.append('DomainOutBedSlope')
        self.XML_element_HydroPars.append('InitialConditionType')
        self.XML_element_HydroPars.append('InitialCondition')

        self.XML_element_HydroPars.append('FroudeNumberCriteria')
        self.XML_element_HydroPars.append('CourantNumber')
        self.XML_element_HydroPars.append('ApplyVNC')

    def Set_XML_element_BoundaryConditionData(self):
        try:
            self.XML_element_BoundaryConditionData=[]
            self.XML_element_BoundaryConditionData.append('CellXY')
            self.XML_element_BoundaryConditionData.append('DataFile')
            self.XML_element_BoundaryConditionData.append('DataType')
        except Exception as e:
            MsError(e)

    def Set_XML_element_DEMFileToChange(self):
        try:
            self.XML_element_DEMFileToChange = []
            self.XML_element_DEMFileToChange.append('DEMFile')
            self.XML_element_DEMFileToChange.append('TimeMinute')
        except Exception as e:
            MsError(e)

class XML_get_set():
    def __init__(self) :
        self.__DEMFileToChange_Count=0
        self.__BoundaryConditionData_Count=0
        self.__BoundaryConditionData_ELCount=0
 
    def getDEMFileToChange_Count(self) :
        return self.__DEMFileToChange_Count

    def setDEMFileToChange_Count(self, DEMFileToChange_Count) :
        self.__DEMFileToChange_Count = DEMFileToChange_Count
 
    def getBoundaryConditionData_Count(self) :
        return self.__BoundaryConditionData_Count
 
    def setBoundaryConditionData_Count(self, BoundaryConditionData_Count) :
        self.__BoundaryConditionData_Count = BoundaryConditionData_Count


    def getBoundaryConditionData_ELCount(self) :
        return self.__BoundaryConditionData_ELCount
 
    def setBoundaryConditionData_ELCount(self, BoundaryConditionData_ELCount) :
        self.__BoundaryConditionData_ELCount = BoundaryConditionData_ELCount
