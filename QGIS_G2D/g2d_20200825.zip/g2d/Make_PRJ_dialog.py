import os
from PyQt5 import uic
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDockWidget

# Dockwidget ��Ÿ�� ����
from .lib.Util import *

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'Make_PRJ_dialog_base.ui'))

class MAKE_PRJ(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        super(MAKE_PRJ, self).__init__(parent)
        self.setupUi(self)
